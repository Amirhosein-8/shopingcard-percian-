// This is a catch-all route for all pages that are not defined.
// I don't want next.js show a 404 page for sake of this example, so I'm just returning null.
export default function Page() {
  return null
}
